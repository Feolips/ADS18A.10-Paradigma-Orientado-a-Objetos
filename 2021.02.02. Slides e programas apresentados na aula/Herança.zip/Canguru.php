<?php
require_once 'Mamifero.php';
class Canguru extends Mamifero{
  //sobrepondo o método locomover, pois tem a mesma assinatura
  public function locomover(){
    echo "<p>Saltando</p)";
}  
}

?>