<?php
require_once 'Mamifero.php';
class Cachorro extends Mamifero{
    
}

?>