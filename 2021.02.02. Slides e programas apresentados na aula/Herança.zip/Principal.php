<?php
            require_once 'Animal.php';
            require_once 'Mamifero.php';
            require_once 'Reptil.php';
            require_once 'Peixe.php';
            require_once 'Ave.php';
            require_once 'Canguru.php';
            require_once 'Cachorro.php';
            require_once 'Cobra.php';
            require_once 'Tartaruga.php';
            
            $m = new Mamifero();
            $a = new Ave();
            $r = new Reptil();
            $c = new Canguru();
            $ch = new Cachorro();
            $co = new Cobra();
            $t = new Tartaruga();
            
            
            echo " <b> Classe Mamifero </b>",$m->locomover(),"<br/><br/>";
            echo "<br/>";
            echo " <b> Classe Ave </b> ", $a->locomover(), "<br/><br/>";
            echo "<br/>";
            echo " <b> Classe Reptil </b>", $r->locomover(),"<br/><br/>";
            echo "<br/>";
            echo " <b> Classe Canguru é Mamífero </b>", $c->locomover(),"<br/><br/>";
            echo "<br/>";
            echo " <b> Classe Cobra é Reptíl</b>", $co->locomover(),"<br/><br/>";
            echo "<br/>";
            echo " <b> Classe Tartaruga é Reptíl</b>", $t->locomover(),"<br/><br/>";

            

           

        ?>
        