class Log:
    def __init__(self, dateTime: str, tipo: str, id: int):
        self.dateTime = dateTime
        self.tipo = tipo
        self.id = id
