package com.spring.workMonitor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WorkMonitorApplicationTests {

	@Test
	void contextLoads() {
	}

}
