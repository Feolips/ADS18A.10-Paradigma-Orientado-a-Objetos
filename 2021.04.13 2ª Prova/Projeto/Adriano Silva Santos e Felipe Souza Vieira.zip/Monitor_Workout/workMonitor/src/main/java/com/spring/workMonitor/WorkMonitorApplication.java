package com.spring.workMonitor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
//Classe responsavel por inicializar a API


@SpringBootApplication
public class WorkMonitorApplication {

	public static void main(String[] args) {
		SpringApplication.run(WorkMonitorApplication.class, args);
	}

}
